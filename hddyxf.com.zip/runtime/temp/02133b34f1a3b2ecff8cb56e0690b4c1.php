<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:83:"/Applications/MAMP/htdocs/Tp5/public/../application/index/view/hddy1/showclass.html";i:1559179071;}*/ ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <title></title>
    <link rel="stylesheet" type="text/css" href="../../../public/css/bootstrap.min.css" />
    <link rel="stylesheet" type="text/css" href="../../../public/css/admin-all.css" />
    <link rel="stylesheet" type="text/css" href="../../../public/css/jquery-ui-1.8.22.custom.css" />
    <script type="text/javascript" src="../../../public/css/jquery-ui-1.8.22.custom.min.js"></script>
    

      
</head>
<body>
    <br>
    <table class="table table-striped table-bordered table-condensed list">
        <thead>
            <tr>
                <td colspan="6"><b>班级基本信息</b></td>
            </tr>
        </thead>
        <form method="post" action="editclass">
        <tbody>
           
            <tr>
                <td >班级：</td>
                <td colspan="5">
                    <input name="class" value="<?php echo $data['class']; ?>" type="text" readonly/>
                </td>
                
            </tr>
            
             <tr>
                <td >辅导员：</td>
                <td >
                    <select name="teacherid">
                        <option value="<?php echo $data['teacherid']; ?>">当前:<?php echo $data['teacherinfo']; ?></option>
                         <?php if(is_array($data1) || $data1 instanceof \think\Collection || $data1 instanceof \think\Paginator): $i = 0; $__LIST__ = $data1;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$list): $mod = ($i % 2 );++$i;?>
                        <option value="<?php echo $list['teacherid']; ?>"><?php echo $list['teacherinfo']; ?>-<?php echo $list['collegeinfo']; ?></option>
                         <?php endforeach; endif; else: echo "" ;endif; ?>
                    </select>
                </td>
                <td >所属专业：</td>
                <td ><select name="majorid">
                        <option value="<?php echo $data['majorid']; ?>">当前:<?php echo $data['majorinfo']; ?></option>
                       <?php if(is_array($data2) || $data2 instanceof \think\Collection || $data2 instanceof \think\Paginator): $i = 0; $__LIST__ = $data2;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$list): $mod = ($i % 2 );++$i;?>
                        <option value="<?php echo $list['majorid']; ?>"><?php echo $list['majorinfo']; ?>-<?php echo $list['collegeinfo']; ?></option>
                         <?php endforeach; endif; else: echo "" ;endif; ?>
                    </select>
                    </td>
                <td >所属学院：</td>
                <td >
                    <select name="collegeid">
                        <option value="<?php echo $data['collegeid']; ?>">当前:<?php echo $data['collegeinfo']; ?></option>
                        <?php if(is_array($data3) || $data3 instanceof \think\Collection || $data3 instanceof \think\Paginator): $i = 0; $__LIST__ = $data3;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$list): $mod = ($i % 2 );++$i;?>
                        <option value="<?php echo $list['collegeid']; ?>"><?php echo $list['collegeinfo']; ?></option>
                         <?php endforeach; endif; else: echo "" ;endif; ?>
                    </select>
                    </td>
            </tr>
            
        </tbody>
        <tfoot>
            <tr>
                <td colspan="6">
<!--                    <a href="help" class="btn btn-inverse">保存</a>-->
                    <input class="btn btn-inverse" type="submit" value="提交" />
                   <input class="btn btn-inverse" id="try" type="button" value="刷新" onclick="location.reload()"/>
<!--                     <input class="btn btn-inverse" type="button" value="取消" /></td> -->
&nbsp&nbsp&nbsp&nbsp信息保存成功如页面信息未更新请点击刷新按钮。
    

            </tr>
        </tfoot>
    </from>
    </table>
</body>
</html>
