<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:103:"D:\phpstudy_pro\WWW1\hddy.com_20191009_191824\public/../application/index\view\college\showteacher.html";i:1560826318;}*/ ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <title></title>
    <link rel="stylesheet" type="text/css" href="/css/bootstrap.min.css" />
    <link rel="stylesheet" type="text/css" href="/css/admin-all.css" />
    <link rel="stylesheet" type="text/css" href="/css/jquery-ui-1.8.22.custom.css" />
    <script type="text/javascript" src="/css/jquery-ui-1.8.22.custom.min.js"></script>
    

      
</head>
<body>
    <br>
    <table class="table table-striped table-bordered table-condensed list">
        <thead>
            <tr>
                <td colspan="6"><b>辅导员基本信息</b></td>
            </tr>
        </thead>
        <form method="post" action="editteacher">
        <tbody>
            <input type="hidden" name="teacherid" value="<?php echo $data['teacherid']; ?>" />
            <tr>
                <td >姓名：<font color="FF0000">*</font></td>
                <td >
                    <input name="teacherinfo" value="<?php echo $data['teacherinfo']; ?>" type="text" placeholder='5位以内全汉字'/>
                </td>
                <td >联系方式：<font color="FF0000">*</font></td>
                <td >
                    <input name="teacheradd" value="<?php echo $data['teacheradd']; ?>" type="text" placeholder='11位全数字'/></td>
            </tr>
             <tr>
                 <td >性别：<font color="FF0000">*</font></td>
                <td >
                     <select name="teachersex">
                        <option value="<?php echo $data['teachersex']; ?>">当前：<?php echo $data['teachersex']; ?></option>
                        <option value="男">男</option>
                        <option value="女">女</option>
                         
                </td>
                <td >所在学院：<font color="FF0000">*</font></td>
                <td colspan="3">
                    <select name="collegeid">                      
                         
                         <option value="<?php echo $data['collegeid']; ?>">当前：<?php echo $data['collegeinfo']; ?></option>
                         <?php if(is_array($data1) || $data1 instanceof \think\Collection || $data1 instanceof \think\Paginator): $i = 0; $__LIST__ = $data1;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$list): $mod = ($i % 2 );++$i;?>
                        <option value="<?php echo $list['collegeid']; ?>"><?php echo $list['collegeinfo']; ?></option>
                         <?php endforeach; endif; else: echo "" ;endif; ?>
                    </select>
                </td>
            </tr>
        </tbody>
        <tfoot>
            <tr>
                <td colspan="6">
<!--                    <a href="help" class="btn btn-inverse">保存</a>-->
                    <input class="btn btn-inverse" type="submit" value="提交" />
                   <input class="btn btn-inverse" id="try" type="button" value="刷新" onclick="location.reload()"/>
<!--                     <input class="btn btn-inverse" type="button" value="取消" /></td> -->
&nbsp&nbsp&nbsp&nbsp信息保存成功如页面信息未更新请点击刷新按钮。
    

            </tr>
        </tfoot>
    </from>
    
    </table>
</body>
</html>
