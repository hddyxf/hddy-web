<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:96:"D:\phpstudy_pro\WWW1\hddy.com_20191009_191824\public/../application/index\view\work\adduser.html";i:1560826320;}*/ ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <title></title>
    <link rel="stylesheet" type="text/css" href="/css/bootstrap.min.css" />
    <link rel="stylesheet" type="text/css" href="/css/admin-all.css" />
    <link rel="stylesheet" type="text/css" href="/css/jquery-ui-1.8.22.custom.css" />
    <script type="text/javascript" src="/css/jquery-ui-1.8.22.custom.min.js"></script>
    <script>
        function showCustomer(str)
        {
          var xmlhttp;    
          if (str=="")
          {
            document.getElementById("txtHint").innerHTML="";
            return;
          }
          if (window.XMLHttpRequest)
          {
            // IE7+, Firefox, Chrome, Opera, Safari 浏览器执行代码
            xmlhttp=new XMLHttpRequest();
          }
          else
          {
            // IE6, IE5 浏览器执行代码
            xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
          }
          xmlhttp.onreadystatechange=function()
          {
            if (xmlhttp.readyState==4 && xmlhttp.status==200)
            {
              document.getElementById("txtHint").innerHTML=xmlhttp.responseText;
            }
          }
          xmlhttp.open("GET","userclassmore?q="+str,true);
          xmlhttp.send();
        }
        </script>

</head>
<body>
    <div class="alert alert-info">当前位置<b class="tip"></b>用户管理<b class="tip"></b>添加用户</div>
    <table class="table table-striped table-bordered table-condensed list">
        <thead>
            <tr>
                <td colspan="6"><b>个人基本信息</b></td>
            </tr>
        </thead>
        <form method="post" action="adduserrun" >
        <tbody>
            <tr>
                <td>用户编号：</td>
                <td colspan="5">系统将自动生成</td>
            </tr>
            <tr>
                <td >用户名：<font color="FF0000">*</font></td>
                <td >
                    <input name="username" value="" type="text" placeholder="10位内非汉字且不能包含非法字符"/>
                </td>
                <td >姓名：<font color="FF0000">*</font></td>
                <td >
                    <input name="u_name" value="" type="text" placeholder="5位内姓名或学生组织名，全汉字"/></td>
                <td >性别：</td>
                <td >
                    <input name="u_sex" type="radio" value="男" checked="checked"/>  男
                    <input name="u_sex" type="radio" value="女"  />  女
                </td>
            </tr>
            <tr>
                <td >身份证号码：<font color="FF0000">*</font></td>
                <td >
                    <input name="user_id" value="" type="text" placeholder="18位全数字，最后一位可为X"/>
                </td>
                <td >所属单位：<font color="FF0000">*</font></td>
                <td ><select name="u_class" onchange="showCustomer(this.value)">
                        <option value="">未选择</option>
                        <?php if(is_array($data1) || $data1 instanceof \think\Collection || $data1 instanceof \think\Paginator): $i = 0; $__LIST__ = $data1;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$list): $mod = ($i % 2 );++$i;?>
                        <option value="<?php echo $list['userid']; ?>"><?php echo $list['userinfo']; ?></option>
                         <?php endforeach; endif; else: echo "" ;endif; ?>
                    </select>
                    </td>
                <td >所属单位名称：<font color="FF0000">*</font></td>
                <td>
                    <select name="u_classinfo" id="txtHint">
                    <option value="">未选择</option>
                        
                    </select>
                    
                    </td>
            </tr>
            <tr>
                <td >手机号码：<font color="FF0000">*</font></td>
                <td >
                    <input name="add" value="" type="text" placeholder="11位全数字"/>
                </td>
                <td >邮箱地址：</td>
                <td >
                    <input name="u_mail" value="" type="text" placeholder="邮箱格式"/></td>
                <td >QQ号码：</td>
                <td >
                    <input name="qq" value="" type="text" placeholder="仅支持5-11位全数字"/></td>
            </tr>
            <tr>
                <td >微信号码：</td>
                <td >
                    <input name="vx" value="" type="text" placeholder='支持字母、数字、"—"和"_"组合"'/>
                </td>
                <td >账号状态：</td>
                <td >
                <input name="state" type="radio" value="1" checked="checked"/>  启用
                <input name="state" type="radio" value="2"  />  停用
                </td>
                <td >账号权限：<font color="FF0000">*</font></td>
                <td >
                    <select name="jurisdiction">
                        <option value="">未选择</option>
                        <option value="2">学工处</option>
                        <option value="3">校团委</option>
                        <option value="4">分院院长</option>
                        <option value="5">分院团总支书记</option>
                        <option value="6">分院辅导员</option>
                        <option value="7">学生组织(院级)</option>
                        <option value="8">学生组织(校级)</option>
                        <option value="1">系统维护账号(请谨慎分配此权限账号)</option>
                    </select>
                    </td>
            </tr><input type="hidden" value="123456" name="password" ></input>
        </tbody>
        <tfoot>
            <tr>
                <td colspan="6">
<!--                    <a href="help" class="btn btn-inverse">保存</a>-->
                    <input class="btn btn-inverse" type="submit" value="提交" />
                    <input class="btn btn-inverse" type="reset" value="清空" />
<!--                     <input class="btn btn-inverse" type="button" value="取消" /></td> -->
     &nbsp&nbsp&nbsp&nbsp添加的新用户初始密码为：123456，请及时通知用户及时登录系统修改密码。
            </tr>
        </tfoot>
    </form>
    </table>
</body>
</html>
