<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:78:"/www/wwwroot/hddy.com/tp5/public/../application/index/view/student/stusch.html";i:1576322851;}*/ ?>
<!DOCTYPE html>
<html class="x-admin-sm">
    
    <head>
        <meta charset="UTF-8">
        <meta charset="UTF-8">
      	<meta name="viewport" content="width=device-width,initial-scale=1.0,maximum-scale=1.0,minimum-scale=1.0,user-scalable=no"/>
        <title>欢迎使用学生德育学分管理系统</title>
        <link rel="shortcut icon" href="../../logo.ico" />
        <link rel="stylesheet" href="/css/font.css">
         <link rel="stylesheet" href="/css/xadmin.css">
        <link rel="stylesheet" href="/css/theme.css">
        <script src="/lib/layui/layui.js" charset="utf-8"></script>
        <script type="text/javascript" src="/js/xadmin.js"></script>
        <!--[if lt IE 9]>
          <script src="https://cdn.staticfile.org/html5shiv/r29/html5.min.js"></script>
          <script src="https://cdn.staticfile.org/respond.js/1.4.2/respond.min.js"></script>
        <![endif]-->
    </head>
    
    <body>
        <div class="x-nav">
            <span class="layui-breadcrumb">
                    <a>欢迎：&nbsp<?php echo $data['collegeinfo']; ?> &nbsp&nbsp<?php echo $data['username']; ?>  &nbsp&nbsp <?php echo $data['u_name']; ?> &nbsp&nbsp权限：<?php echo $data['jurisdictioninfo']; ?> <strong>当前测评班长为学分操作系统</strong></a>
            </span>
            <a class="layui-btn layui-btn-small" style="line-height:1.6em;margin-top:3px;float:right;background-color:#4682B4" onclick="location.reload()" title="刷新">
                <i class="layui-icon layui-icon-refresh" style="line-height:30px"></i>
            </a>
        </div>
        <div class="layui-fluid">
                <div class="layui-row layui-col-space15">
                    <div class="layui-col-md12">
                        <div class="layui-card">
                            <div class="layui-card-body ">          
                                 <h4><a class="layui-btn layui-btn-sm"   href="<?php echo url('stulog'); ?>"style="background-color:#4682B4">
                                   &nbsp查看个人操作日志</a>
                                   <a class="layui-btn layui-btn-sm"  href="<?php echo url('stuoperation'); ?>"style="background-color:#FF5511">
                                        &nbsp学分操作</a>
                                        <a class="layui-btn layui-btn-sm"  href="<?php echo url('goout'); ?>"style="background-color:#FF5511">
                                                &nbsp退出登陆</a>
                                  </h4>                     
                            </div>
                        </div>
                    </div>
                </div> 
            </div>   
        <div class="layui-fluid">
            <div class="layui-row layui-col-space15">
                <div class="layui-col-md12">
                    <div class="layui-card">
                        <div class="layui-card-body ">
                            <form class="layui-form layui-col-space5">
                                <div class="layui-inline layui-show-xs-block">
                                    <input type="text"  placeholder="关键字查询" autocomplete="off" class="layui-input" name="ssk" id="ssk" ></div>
                                <div class="layui-inline layui-show-xs-block">
                                    <div class="layui-btn layui-btn-sm" lay-submit="" data-type="reload" id="tj" lay-filter="sreach" style="background-color:#4682B4">
                                        <i class="layui-icon">&#xe615;</i></div>
                                        <strong><i class="layui-icon">&nbsp&nbsp&#xe609;&nbsp支持学生学号 学生姓名的精确及模糊查询，查询结果将会在下方表格显示。(输入“_”可查询所有信息)</i> </strong>
                                    </div>
                            </form>
                        </div><table id="demo" lay-filter="test" class="layui-card-body" ></table>
                        <script type="text/html" id="barDemo" >
                            <a class="layui-btn layui-btn-normal" lay-event="detail" style="background-color:#708090">操作</a>&nbsp&nbsp&nbsp
</script>
                    </div>
                </div>
            </div>
             <div >
                                本系统由 数据科学与人工智能学院 软件工程系 提供技术支持，并持有版权。
                        </div>
        </div>
         
    </body>
   
    <script>layui.use('laydate',
        function() {
            var laydate = layui.laydate;

            //执行一个laydate实例
            laydate.render({
                elem: '#start' //指定元素
            });

            //执行一个laydate实例
            laydate.render({
                elem: '#end' //指定元素
            });
            

        });</script>
    
<script>
  layui.use('table', function(){
  var table = layui.table;
  var index = layer.load(2);
  table.render({
    elem: '#demo'
    ,url:'scoreoperationlist'
    ,toolbar: '#toolbarDemo'
    ,title: '用户数据表'
    ,cols: [[
    {type:'numbers',title:'序号',},
    {field:'s_id', title:'学号',width:120}
      ,{field:'s_name', title:'姓名',width:120}
      ,{field:'s_sex', title:'性别',width:100}
      ,{field:'collegeinfo', title:'所在学院',}
      ,{field:'majorinfo', title:'专业名称',width:200}
      ,{field:'s_class', title:'所在班级',width:100}
      ,{field:'teacherinfo', title:'辅导员',width:120}
      ,{ field:'1',title:'操作', toolbar: '#barDemo',width:160}]]
      ,limit:40
    ,page: true
    ,done:function () {
                        layer.close(index) //加载完数据
                    }
  });
       

        var active = {
            reload: function(){
                var index = layer.load(2);
                var stuname = $('#ssk').val(); //传入搜索值 
                //console.log((username));验证值是否获取
                //执行重载
                table.reload('demo', {
                    url : 'stuschop',
                    method:'post',
                    page: {
                        curr: 1 //重新从第 1 页开始
                    }
                    ,where: { //类似于 data
                        stuname:stuname //传入日期参数
                        ,done:function () {
                        layer.close(index) //加载完数据
                    }
                    }
                });
            }
        };
        
      var table = layui.table;
      
      //监听单元格编辑
     table.on('tool(test)', function(obj){
    var data = obj.data;
   
    if(obj.event === 'detail'){
         layer.open({
    type: 2,
    title: false,
    shadeClose: true,
    shade: 0.4,
    area: ['90%', '50%'],
    
    content: 'stucollshowstu1?id='+data.s_id //iframe的url
  });
    }
    
    else{
    console.log(('111'));
    }
  });
  
               
            
        $('#tj').on('click', function(){
            var type = $(this).data('type');
            //不能为空验证
            if( $('#ssk').val()==""){
                layer.msg('查询内容不能为空');
                return false;
            }
            active[type] ? active[type].call(this) : '';
        });
     $(document).on('keydown',function(e){
      if(e.keyCode == 13){
        $('#tj').trigger('click');
        return false;
      }
        })

         });
         
</script>
 
</html>