<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:97:"/Applications/MAMP/htdocs/德育开发版/public/../application/index/view/work/scoreshowstu.html";i:1560784684;}*/ ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <title></title>
    <link rel="stylesheet" type="text/css" href="../../../public/css/bootstrap.min.css" />
    <link rel="stylesheet" type="text/css" href="../../../public/css/admin-all.css" />
    <link rel="stylesheet" type="text/css" href="../../../public/css/jquery-ui-1.8.22.custom.css" />
    <script type="text/javascript" src="../../../public/css/jquery-ui-1.8.22.custom.min.js"></script>
    <script>
            function showCustomer(str)
            {
              var xmlhttp;    
              if (str=="")
              {
                document.getElementById("txtHint").innerHTML="";
                return;
              }
              if (window.XMLHttpRequest)
              {
                // IE7+, Firefox, Chrome, Opera, Safari 浏览器执行代码
                xmlhttp=new XMLHttpRequest();
              }
              else
              {
                // IE6, IE5 浏览器执行代码
                xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
              }
              xmlhttp.onreadystatechange=function()
              {
                if (xmlhttp.readyState==4 && xmlhttp.status==200)
                {
                  document.getElementById("txtHint").innerHTML=xmlhttp.responseText;
                }
              }
              xmlhttp.open("GET","scoresec?q="+str,true);
              xmlhttp.send();
            }
            </script>
</head>
<body>
    
    <form method="post" action="scoreoperationrun">
    <table class="table table-striped table-bordered table-condensed list">
        <thead>
            <tr>
                <td colspan="6"><b><strong>被操作人(学生)信息</strong></b></td>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td width=><strong>被操作人(学生)学号</strong></td>
                <td colspan="5" width="80%"><input type="hidden" name="stuid" value="<?php echo $data2['s_id']; ?>" /><?php echo $data2['s_id']; ?>
                </td>
            </tr>
            <tr>
                <td width="15%"><strong>被操作人(学生)姓名：</strong></td>
                <td width="15%">
                        <input type="hidden" name="stuname" value="<?php echo $data2['s_name']; ?>" /><?php echo $data2['s_name']; ?>
                </td>
                <td width="15%"><strong>性别：</strong></td>
                <td width="15%">
                        <input type="hidden" name="stusex" value="<?php echo $data2['s_sex']; ?>" /><?php echo $data2['s_sex']; ?>
                    </td>
                <td width="15%"><strong>班级：</strong></td>
                <td width="25%">
                        <input type="hidden" name="stuclass" value="<?php echo $data2['s_class']; ?>" /><?php echo $data2['s_class']; ?></td>
            </tr>
            <tr>
                <td ><strong>所在学院：</strong></td>
                <td >
                    <input type="hidden" name="opcollege" value="<?php echo $data2['collegeid']; ?>" /><?php echo $data2['collegeinfo']; ?>
                </td>
                <td ><strong>所在专业：</strong></td>
                <td >
                        <input type="hidden" name="opmajor" value="<?php echo $data2['majorid']; ?>" /> <?php echo $data2['majorinfo']; ?>
                    </td>
                <td ><strong>辅导员：</strong></td>
                <td >
                        <input type="hidden" name="opteacher" value="<?php echo $data2['teacherid']; ?>" /><?php echo $data2['teacherinfo']; ?>
                    </td>
            </tr>     
        </tbody>
    </table>
    <table class="table table-striped table-bordered table-condensed list">
            <thead>
                <tr>
                    <td colspan="6"><b><strong>操作人信息</strong></b></td>
                </tr>
            </thead>
            <form method="post" action="informationmodify">
            <tbody>
                <tr>
                    <td ><strong>操作人用户名：</strong></td>
                    <td  ><input type="hidden" name="opusername" value="<?php echo $data['username']; ?>" /><?php echo $data['username']; ?></td>
                    <td ><strong>操作人权限：</strong></td>
                    <td colspan="3">
                        <input type="hidden" name="opjurisdiction" value="<?php echo $data['jurisdiction']; ?>" /><?php echo $data['jurisdictioninfo']; ?>
                    </td>
                </tr>
                <tr>
                    <td width="15%"><strong>操作人姓名：</strong></td>
                    <td width="15%">
                            <input type="hidden" name="opname" value="<?php echo $data['u_name']; ?>" /><?php echo $data['u_name']; ?>
                    </td>
                    <td width="15%"><strong>操作人所属单位：</strong></td>
                    <td width="15%">
                            <input type="hidden" name="opclass" value="<?php echo $data['u_class']; ?>" /><?php echo $data['userinfo']; ?></td>
                    <td width="15%"><strong>操作人所属单位名称：</strong></td>
                    <td width="25%">
                            <input type="hidden" name="opclassinfo" value="<?php echo $data['u_classinfo']; ?>" /><?php echo $data['collegeinfo']; ?></td>
                </tr>
            </tbody>
        </table>
        <table class="table table-striped table-bordered table-condensed list">
                <thead>
                    <tr>
                        <td colspan="6"><b><strong>操作信息</strong></b></td>
                    </tr>
                </thead>
                <form method="post" action="informationmodify">
                <tbody>
                        <tr>
                                <td ><strong>学分操作一级分类：</strong></td>
                                <td >
                                        <select name="opscorefir" onchange="showCustomer(this.value)">
                                                <option value="">未选择</option>    
                                            <?php if(is_array($data3) || $data3 instanceof \think\Collection || $data3 instanceof \think\Paginator): $i = 0; $__LIST__ = $data3;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$list): $mod = ($i % 2 );++$i;?>
                                                <option value="<?php echo $list['scoreid']; ?>"><?php echo $list['scoreinfo']; ?></option>
                                                 <?php endforeach; endif; else: echo "" ;endif; ?>
                                        </select>
                                </td>
                                <td ><strong>学分操作二级分类：</strong></td>
                                <td colspan="3">
                                        <div id="txtHint">选择一级分类后将会显示</div>
                                       
                                </td>
                            </tr>
                    <tr>
                        <td width="15%"><strong>操作类型：</strong></td>
                        <td width="15%">
                                <select name="opscoreclass">
                                        <option value="">未选择</option>
                                        <option value="1">加分</option>
                                        <option value="2">减分</option>
                                    </select>       
                        </td>
                        <td width="15%"><strong>操作分值：</strong></td>
                        <td width="15%">
                                <select name="score">
                                        <option value="">未选择</option>
                                        <option value="1">1分</option>
                                        <option value="2">2分</option>
                                        <option value="3">3分</option>
                                        <option value="4">4分</option>
                                        <option value="5">5分</option>
                                        <option value="6">6分</option>
                                        <option value="7">7分</option>
                                        <option value="8">8分</option>
                                        <option value="9">9分</option>
                                        <option value="10">10分</option>
                                        <option value="11">11分</option>
                                        <option value="12">12分</option>
                                    </select>       
                        </td>
                        <td width="15%"><strong>操作状态：</strong></td>
                        <td width="25%">提交后立即确认
                               
                    </td>
                    </tr>
                </tbody>
                <tfoot>
                    <tr>
                        <td colspan="6">
        
                            <input class="btn btn-inverse" id="find" type="submit" value="提交" />
                    </tr>
                </tfoot>
            </from>
            </table>
</body>
</html>
