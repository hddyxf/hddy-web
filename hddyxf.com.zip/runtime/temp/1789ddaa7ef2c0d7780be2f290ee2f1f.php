<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:82:"/Applications/MAMP/htdocs/Tp5/public/../application/index/view/hddy1/scorelog.html";i:1559470953;}*/ ?>
<h1>开发中。。。</h1>