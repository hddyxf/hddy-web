<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:88:"/www/wwwroot/192.168.58.38/tp5/public/../application/index/view/college/information.html";i:1560826315;}*/ ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <title></title>
    <link rel="stylesheet" type="text/css" href="/css/bootstrap.min.css" />
    <link rel="stylesheet" type="text/css" href="/css/admin-all.css" />
    <link rel="stylesheet" type="text/css" href="/css/jquery-ui-1.8.22.custom.css" />
    <script type="text/javascript" src="/css/jquery-ui-1.8.22.custom.min.js"></script>
</head>
<body>
    <div class="alert alert-info">当前位置<b class="tip"></b>个人管理<b class="tip"></b>个人信息</div>
    <table class="table table-striped table-bordered table-condensed list">
        <thead>
            <tr>
                <td colspan="6"><b>个人基本信息</b></td>
            </tr>
        </thead>
         <?php foreach($data as $value): ?>
        <form method="post" action="informationmodify">
        <tbody>
            <tr>
                <td>用户编号</td>
                <td colspan="5"><?php echo $value['u_id']; ?></td>
            </tr>
            <tr>
                <td >用户名：</td>
                <td >
                    <input name="username" value="<?php echo $value['username']; ?>" type="text" readonly/>
                </td>
                <td >姓名：</td>
                <td >
                    <input name="" value="<?php echo $value['u_name']; ?>" type="text" readonly/></td>
                <td >性别：</td>
                <td >
                    <input name="" value="<?php echo $value['u_sex']; ?>" type="text" readonly/></td>
            </tr>
            <tr>
                <td >身份证号码：</td>
                <td >
                    <input name="" value="<?php echo $value['user_id']; ?>" type="text" readonly/>
                </td>
                <td >所属单位：</td>
                <td >
                    <input name="" value="<?php echo $value['userinfo']; ?>" type="text" readonly/></td>
                <td >所属单位名称：</td>
                <td >
                    <input name="" value="<?php echo $value['collegeinfo']; ?>" type="text" readonly/></td>
            </tr>
            <tr>
                <td >手机号码：<font color="FF0000">*</font></td>
                <td >
                    <input name="add" value="<?php echo $value['add']; ?>" type="text" placeholder="仅支持11位全数字"/>
                </td>
                <td >邮箱地址：</td>
                <td >
                    <input name="u_mail" value="<?php echo $value['u_mail']; ?>" type="text" placeholder="****@***.com"/></td>
                <td >QQ号码：</td>
                <td >
                    <input name="qq" value="<?php echo $value['qq']; ?>" type="text" placeholder="仅支持5-11位全数字"/></td>
            </tr>
            <tr>
                <td >微信号码：</td>
                <td >
                    <input name="vx" value="<?php echo $value['vx']; ?>" type="text" placeholder=""/>
                </td>
                <td >账号状态：</td>
                <td colspan="3">
                    <input name="" value="<?php echo $value['stateinfo']; ?>" type="text" readonly/></td>
            </tr>
        </tbody>
        
        <tfoot>
            <tr>
                <td colspan="6">
<!--                    <a href="help" class="btn btn-inverse">保存</a>-->
                    <input class="btn btn-inverse" id="find" type="submit" value="保存" />
                    <input class="btn btn-inverse" id="try" type="button" value="刷新" onclick="location.reload()"/>
                    <!--                     <input class="btn btn-inverse" type="button" value="取消" /></td> -->
                    &nbsp&nbsp&nbsp&nbsp信息保存成功如页面信息未更新请点击刷新按钮。
            </tr>
        </tfoot>
    </from>
        <?php endforeach; ?> 
    </table>
</body>
</html>
