<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:85:"/www/wwwroot/192.168.58.38/tp5/public/../application/index/view/work/addscoresec.html";i:1560826320;}*/ ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <title></title>
    <link rel="stylesheet" type="text/css" href="/css/bootstrap.min.css" />
    <link rel="stylesheet" type="text/css" href="/css/admin-all.css" />
    <link rel="stylesheet" type="text/css" href="/css/jquery-ui-1.8.22.custom.css" />
    <script type="text/javascript" src="/css/jquery-ui-1.8.22.custom.min.js"></script>
    

      
</head>
<body>
    <br>
    <table class="table table-striped table-bordered table-condensed list">
        <thead>
            <tr>
                <td colspan="6"><b>学分操作二级分类信息</b></td>
            </tr>
        </thead>
        <form method="post" action="addscoresecrun">
        <tbody>
           
            <tr>
                <td >操作项所属一级分类：</td>
                <td >
                     <select name="scorefirid">
                        <option value="">未选择</option>
                        <?php if(is_array($data) || $data instanceof \think\Collection || $data instanceof \think\Paginator): $i = 0; $__LIST__ = $data;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$list): $mod = ($i % 2 );++$i;?>
                        <option value="<?php echo $list['scoreid']; ?>"><?php echo $list['scoreinfo']; ?></option>
                         <?php endforeach; endif; else: echo "" ;endif; ?>
                    </select>                   
                </td>
                <td >操作类型：</td>
                <td >
                     <select name="classid">
                        <option value="">未选择</option>
                        <option value="1">加分</option>
                        <option value="2">减分</option>
                       
                    </select>                   
                </td>
                <td >操作分值上限：</td>
                <td >
                     <select name="score">
                        <option value="">未选择</option>
                        <option value="1">1分</option>
                        <option value="2">2分</option>
                        <option value="3">3分</option>
                        <option value="4">4分</option>
                        <option value="5">5分</option>
                        <option value="6">6分</option>
                        <option value="7">7分</option>
                        <option value="8">8分</option>
                        <option value="9">9分</option>
                        <option value="10">10分</option>
                        <option value="11">11分</option>
                        <option value="12">12分</option>
                    </select>                   
                </td>
            </tr>
            
             <tr>
                <td width="140">具体描述：</td>
                <td colspan="5">
                  <textarea name="scoresecinfo" style="width: 95%" rows="4" cols="5" placeholder="支持中英文、数字、逗号、句号，且不能超过100个字符"></textarea>
                </td>
            </tr>
        </tbody>
        <tfoot>
            <tr>
                <td colspan="6">
<!--                    <a href="help" class="btn btn-inverse">保存</a>-->
                    <input class="btn btn-inverse" type="submit" value="提交" />
                    <input class="btn btn-inverse" type="reset" value="清空" />
<!--                     <input class="btn btn-inverse" type="button" value="取消" /></td> -->
    

            </tr>
        </tfoot>
    </from>
    </table>
</body>
</html>
