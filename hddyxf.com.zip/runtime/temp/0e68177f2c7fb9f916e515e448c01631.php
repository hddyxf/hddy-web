<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:77:"/www/wwwroot/hddy.com/tp5/tp5/public/../application/index/view/hddy1/log.html";i:1570359354;}*/ ?>
<!DOCTYPE html>
<html class="x-admin-sm">

<head>
    <meta charset="UTF-8">

    <title>欢迎页面-X-admin2.2</title>
    <link rel="shortcut icon" href="../../logo.ico" />
    <link rel="stylesheet" href="/css/font.css">
    <link rel="stylesheet" href="/css/xadmin.css">
    <link rel="stylesheet" href="/css/theme.css">
    <script src="/lib/layui/layui.js" charset="utf-8"></script>
    <script type="text/javascript" src="/js/xadmin.js"></script>
    <script>
        //这里代码多了几行，但是不会延迟显示，速度比较好，格式可以自定义，是理想的时间显示
        setInterval("fun(show_time)", 1);

        function fun(timeID) { 
            var date = new Date();  //创建对象  
            var y = date.getFullYear();    //获取年份  
            var m = date.getMonth() + 1;   //获取月份  返回0-11  
            var d = date.getDate(); // 获取日  
            var w = date.getDay();   //获取星期几  返回0-6   (0=星期天) 
            var ww = ' 星期' + '日一二三四五六'.charAt(new Date().getDay()); //星期几
            var h = date.getHours();  //时
            var minute = date.getMinutes()  //分
            var s = date.getSeconds(); //秒
            var sss = date.getMilliseconds(); //毫秒
            if (m < 10) {
                m = "0" + m;
            }
            if (d < 10) {
                d = "0" + d;
            }
            if (h < 10) {
                h = "0" + h;
            }
            if (minute < 10) {
                minute = "0" + minute;
            }
            if (s < 10) {
                s = "0" + s;
            }
            if (sss < 10) {
                sss = "00" + sss;
            } else if (sss < 100) {
                sss = "0" + sss;
            }
            document.getElementById(timeID.id).innerHTML =  y + "年" + m + "月" + d + "日 " + h + ":" + minute + ":" + s + "" + ww;  
        }
    </script>
</head>

<body>
    <div class="layui-fluid">
        <div class="layui-row layui-col-space15">
            <div class="layui-col-md12">
                <div class="layui-card">
                    <div class="layui-card-body ">
                        <blockquote class="layui-elem-quote">欢迎管理员：
                            <span class="x-red"><?php echo \think\Request::instance()->session('username'); ?></span> 当前时间: <span id="show_time"></span>
                            <span>&nbsp&nbsp已连接至&nbsp德育学分测试服务器</span>
                        </blockquote>
                    </div>
                </div>
            </div>

            <br>

            <div class="layui-row layui-col-space15">
                <div class="layui-col-md12">
                    <div class="layui-card">
                        <div class="layui-card-header">
                            更新日志
                        </div>
                        <div class="layui-card-body ">
                            <ul class="layui-timeline">
                                <!-- <li class="layui-timeline-item">
                              <i class="layui-icon layui-timeline-axis">&#xe63f;</i>
                              <div class="layui-timeline-content layui-text">
                                <h3 class="layui-timeline-title">2000-00-00</h3>
                                <p>
                                  内容<br>  

                                  内容<br>

                                  内容
                                </p>
                              </div>
                            </li>
                            <li class="layui-timeline-item">
                              <i class="layui-icon layui-timeline-axis">&#xe63f;</i>
                              <div class="layui-timeline-content layui-text">
                                <h3 class="layui-timeline-title">2000-00-01</h3>
                                <p>
                                  内容<br>  

                                  内容<br>

                                  内容
                                </p>
                              </div>
                            </li> -->
                                <li class="layui-timeline-item">
                                    <i class="layui-icon layui-timeline-axis">&#xe63f;</i>
                                    <div class="layui-timeline-content layui-text">
                                        <h3 class="layui-timeline-title">2019-09-30</h3>
                                        <p>
                                            系统版本已从v 2.0.616&nbsp更新至v 2.0.617 &nbsp&nbsp&nbsp&nbsp 本次更新共修复/完善了以下已知的问题。<br> 修复了登陆失败验证码输入框无法重置。

                                            <br> 完善了密码验证规则。
                                            <br> 修改设计上的缺陷：删除学院同时删除下属专业。？？
                                            <br> 完善了学分操作的查询条件
                                            <br> 新增了右上角查看个人信息的功能模块
                                            <br> 去掉了学生身份证信息可编辑的功能
                                            <br> 修复了批量上传学生时，出现对应班级不一致？？
                                            <br> 解决了学分操作时出现参数异常
                                            <br> 完善添加学生信息成功后，查询不到该学生信息
                                            <br> 修复行政班级与班级管理信息不对应？？
                                            <br> ...


                                            <br>


                                        </p>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <style id="welcome_style"></style>
        <div>
            本系统由 电子与信息工程学院 软件工程系 提供技术支持，并持有版权。
        </div>
    </div>
</body>

</html>