<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:72:"/www/wwwroot/hddy.com/tp5/public/../application/index/view/work/log.html";i:1571886406;}*/ ?>
<!DOCTYPE html>
<html class="x-admin-sm">
    <head>
        <meta charset="UTF-8">
        
        <title>欢迎页面-X-admin2.2</title>
       <link rel="shortcut icon" href="../../logo.ico" />
        <link rel="stylesheet" href="/css/font.css">
        <link rel="stylesheet" href="/css/xadmin.css">
        <link rel="stylesheet" href="/css/theme.css">
        <script src="/lib/layui/layui.js" charset="utf-8"></script>
        <script type="text/javascript" src="/js/xadmin.js"></script>
<script>  
//这里代码多了几行，但是不会延迟显示，速度比较好，格式可以自定义，是理想的时间显示
setInterval("fun(show_time)",1);
function fun(timeID){ 
var date = new Date();  //创建对象  
var y = date.getFullYear();     //获取年份  
var m =date.getMonth()+1;   //获取月份  返回0-11  
var d = date.getDate(); // 获取日  
var w = date.getDay();   //获取星期几  返回0-6   (0=星期天) 
var ww = ' 星期'+'日一二三四五六'.charAt(new Date().getDay()) ;//星期几
var h = date.getHours();  //时
var minute = date.getMinutes()  //分
var s = date.getSeconds(); //秒
var sss = date.getMilliseconds() ; //毫秒
    if(m<10){
        m = "0"+m;}
    if(d<10){
        d = "0"+d;}
    if(h<10){
        h = "0"+h;}
    if(minute<10){
        minute = "0"+minute;} 
    if(s<10){
        s = "0"+s;}
    if(sss<10){
        sss = "00"+sss;}
        else if(sss<100){
      sss = "0"+sss;
      }
  document.getElementById(timeID.id).innerHTML =  y+"年"+m+"月"+d+"日 "+h+":"+minute+":"+s+""+ww; 
  }
</script>
    </head>
    <body>
        <div class="layui-fluid">
            <div class="layui-row layui-col-space15">
                <div class="layui-col-md12">
                    <div class="layui-card">
                        <div class="layui-card-body ">
                            <blockquote class="layui-elem-quote">欢迎学工处／校团委：
                                <span class="x-red"><?php echo \think\Request::instance()->session('username'); ?></span>    当前时间:   <span id="show_time"></span>
                                <span>&nbsp&nbsp已连接至&nbsp德育学分测试服务器</span>
                            </blockquote>
                        </div>
                    </div>
                </div>
               
                <br>
                 
            <div class="layui-row layui-col-space15">
                <div class="layui-col-md12">
                    <div class="layui-card">
                        <div class="layui-card-header">
                          更新日志
                        </div>
                        <div class="layui-card-body ">
                          <ul class="layui-timeline">
                            <!-- <li class="layui-timeline-item">
                              <i class="layui-icon layui-timeline-axis">&#xe63f;</i>
                              <div class="layui-timeline-content layui-text">
                                <h3 class="layui-timeline-title">2000-00-00</h3>
                                <p>
                                  内容<br>  

                                  内容<br>

                                  内容
                                </p>
                              </div>
                            </li>
                            <li class="layui-timeline-item">
                              <i class="layui-icon layui-timeline-axis">&#xe63f;</i>
                              <div class="layui-timeline-content layui-text">
                                <h3 class="layui-timeline-title">2000-00-01</h3>
                                <p>
                                  内容<br>  

                                  内容<br>

                                  内容
                                </p>
                              </div>
                            </li> -->
                            <li class="layui-timeline-item">
                              <i class="layui-icon layui-timeline-axis">&#xe63f;</i>
                              <div class="layui-timeline-content layui-text">
                                <h3 class="layui-timeline-title">2019-06-08</h3>
                                <p>
                                  系统版本已从v 2.0.602&nbsp更新至v 2.0.609  &nbsp&nbsp&nbsp&nbsp  本次更新共修复/完善了10个已知的问题。<br>

                                  修复了退出登陆的功能。<br>
                                  完善了登陆页面验证码不能自动刷新的问题。<br>
                                  完善了进入系统主界面后点击浏览器返回按钮后页面会出现Bug，由于系统层级架构，现在已禁用了浏览器返回按钮，但退出登陆操作仍然有效。<br>
                                  完善了新增学生信息和批量上传学生信息的大多数已知问题。<br>
                                  完善了修改密码后仍可对数据进行操作的问题，现在修改密码后系统会在3秒后自动跳转至登陆页面。<br>
                                  完善了绝大多数已知的文本框数据合法性验证的问题。<br> 
                                  修复了个人操作日志模块中显示“数据接口异常”的问题。<br>
                                  新增了在需要加载大量数据时的动态加载状态。<br>
                                  新增了学生学分查询及帮助页面的返回登录按钮。<br>
                                  优化了部分控件样式及页面样式。<br>
                                  
              
                                  感谢各位对本系统进行测试，以使我们开发团队更加完善本系统，更多Bug等你来发掘。<br>


                                </p>
                              </div>
                            </li>
                          </ul>
                    </div>
                  </div>
                </div>
              </div>
            </div>
                <style id="welcome_style"></style>
                        <div >
                                本系统由 数据科学与人工智能学院 软件工程系 提供技术支持，并持有版权。
                        </div>
        </div>
    </body>
</html>