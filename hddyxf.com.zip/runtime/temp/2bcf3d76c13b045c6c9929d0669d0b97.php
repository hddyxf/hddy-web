<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:84:"/www/wwwroot/www.hddy.com/tp5/public/../application/index/view/hddy1/addcollege.html";i:1560826316;}*/ ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <title></title>
    <link rel="stylesheet" type="text/css" href="/css/bootstrap.min.css" />
    <link rel="stylesheet" type="text/css" href="/css/admin-all.css" />
    <link rel="stylesheet" type="text/css" href="/css/jquery-ui-1.8.22.custom.css" />
    <script type="text/javascript" src="/css/jquery-ui-1.8.22.custom.min.js"></script>
    

      
</head>
<body>
    <br>
    <table class="table table-striped table-bordered table-condensed list">
        <thead>
            <tr>
                <td colspan="6"><b>学院基本信息</b></td>
            </tr>
        </thead>
        <form method="post" action="addcollegerun">
        <tbody>
           
            <tr>
                <td width="15%">学院名称：<font color="FF0000">*</font></td>
                <td colspan='5' >
                
                    <input name="collegeinfo" value="" type="text" placeholder='15位以内全汉字' style="width: 95%"/>
                </td>
               
            </tr>
        </tbody>
        <tfoot>
            <tr>
                <td colspan="6">
<!--                    <a href="help" class="btn btn-inverse">保存</a>-->
                    <input class="btn btn-inverse" type="submit" value="提交" />
                     <input class="btn btn-inverse" type="reset" value="清空" />
<!--                     <input class="btn btn-inverse" type="button" value="取消" /></td> -->
    

            </tr>
        </tfoot>
    </from>
    </table>
</body>
</html>
