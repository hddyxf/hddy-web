<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:87:"D:\phpstudy_pro\WWW1\hddyxf.com\public/../application/index\view\hddy1\showcollege.html";i:1560826316;}*/ ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <title></title>
    <link rel="stylesheet" type="text/css" href="/css/bootstrap.min.css" />
    <link rel="stylesheet" type="text/css" href="/css/admin-all.css" />
    <link rel="stylesheet" type="text/css" href="/css/jquery-ui-1.8.22.custom.css" />
    <script type="text/javascript" src="/css/jquery-ui-1.8.22.custom.min.js"></script>
    

      
</head>
<body>
    <br>
    <table class="table table-striped table-bordered table-condensed list">
        <thead>
            <tr>
                <td colspan="6"><b>学院基本信息</b></td>
            </tr>
        </thead>
        <form method="post" action="editcollege">
        <tbody>
           
            <tr>
                <td width="30%">学院名称：<font color="FF0000">*</font></td>
                <td colspan='5'>
                    <input name="collegeid" value="<?php echo $data['collegeid']; ?>" type="hidden" />
                    <input name="collegeinfo" value="<?php echo $data['collegeinfo']; ?>" type="text" placeholder='15位以内全汉字' style="width: 95%"/>
                </td>
               
            </tr>
        </tbody>
        <tfoot>
            <tr>
                <td colspan="6">
<!--                    <a href="help" class="btn btn-inverse">保存</a>-->
                    <input class="btn btn-inverse" type="submit" value="提交" />
                    <input class="btn btn-inverse" id="try" type="button" value="刷新" onclick="location.reload()"/>
<!--                     <input class="btn btn-inverse" type="button" value="取消" /></td> -->
&nbsp&nbsp&nbsp&nbsp信息保存成功如页面信息未更新请点击刷新按钮。
<!--                     <input class="btn btn-inverse" type="button" value="取消" /></td> -->
    

            </tr>
        </tfoot>
    </from>
   
    </table>
        学院下设专业：
            <table class="table table-striped table-bordered table-condensed" id="top">
        <thead>
            <tr class="tr_detail">
                
                <td class="auto-style1" >专业名称</td>
                
            </tr>
        </thead>
        <tbody>
            <?php if(is_array($data2) || $data2 instanceof \think\Collection || $data2 instanceof \think\Paginator): $i = 0; $__LIST__ = $data2;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$list): $mod = ($i % 2 );++$i;?>
            <tr>
                
                <td><?php echo $list['majorinfo']; ?></td>
              
            </tr>
            <?php endforeach; endif; else: echo "" ;endif; ?>
        </tbody>
    </table>
         </table>
        学院内辅导员：
            <table class="table table-striped table-bordered table-condensed" id="top">
        <thead>
            <tr class="tr_detail">
              
                <td class="auto-style1" width="30%">辅导员姓名</td>
                <td class="auto-style1">性别</td>
                
                
            </tr>
        </thead>
        <tbody>
            <?php if(is_array($data1) || $data1 instanceof \think\Collection || $data1 instanceof \think\Paginator): $i = 0; $__LIST__ = $data1;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$list): $mod = ($i % 2 );++$i;?>
            <tr>
               
                <td><?php echo $list['teacherinfo']; ?></td>
                <td><?php echo $list['teachersex']; ?></td>
                
                
            </tr>
            <?php endforeach; endif; else: echo "" ;endif; ?>
        </tbody>
    </table>
        学院内班级：
            <table class="table table-striped table-bordered table-condensed" id="top">
        <thead>
            <tr class="tr_detail">
                <td class="auto-style1" width="30%">班级</td>
                <td class="auto-style1">辅导员姓名</td>
            </tr>
        </thead>
        <tbody>
            <?php if(is_array($data3) || $data3 instanceof \think\Collection || $data3 instanceof \think\Paginator): $i = 0; $__LIST__ = $data3;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$list): $mod = ($i % 2 );++$i;?>
            <tr>
                <td><?php echo $list['class']; ?></td>
                <td><?php echo $list['teacherinfo']; ?></td>
 
            </tr>
            <?php endforeach; endif; else: echo "" ;endif; ?>
        </tbody>
    </table>
</body>
</html>
