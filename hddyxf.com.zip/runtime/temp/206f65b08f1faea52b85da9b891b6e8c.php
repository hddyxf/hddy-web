<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:110:"/Applications/MAMP/htdocs/德育开发版/public/../application/index/view/instructordoub/editpersonallog.html";i:1560081359;}*/ ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <title></title>
    <link rel="stylesheet" type="text/css" href="../../../public/css/bootstrap.min.css" />
    <link rel="stylesheet" type="text/css" href="../../../public/css/admin-all.css" />
    <link rel="stylesheet" type="text/css" href="../../../public/css/jquery-ui-1.8.22.custom.css" />
    <script type="text/javascript" src="../../../public/css/jquery-ui-1.8.22.custom.min.js"></script>
</head>
<body>
    <br>
   
    <table class="table table-striped table-bordered table-condensed list">
        <thead>
            <tr>
                <td colspan="6"><b><strong>被操作人(学生)信息</strong></b></td>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td width=><strong>被操作人(学生)学号</strong></td>
                <td colspan="5" width="80%"><?php echo $data['s_id']; ?>
                </td>
            </tr>
            <tr>
                <td width="15%"><strong>被操作人(学生)姓名：</strong></td>
                <td width="15%">
                        <?php echo $data['s_name']; ?>
                </td>
                <td width="15%"><strong>性别：</strong></td>
                <td width="15%">
                        <?php echo $data['s_sex']; ?>
                    </td>
                <td width="15%"><strong>班级：</strong></td>
                <td width="25%">
                        <?php echo $data['s_class']; ?></td>
            </tr>
            <tr>
                <td ><strong>所在学院：</strong></td>
                <td >
                        <?php echo $data['collegeinfo']; ?>
                </td>
                <td ><strong>所在专业：</strong></td>
                <td >
                        <?php echo $data['majorinfo']; ?>
                    </td>
                <td ><strong>辅导员：</strong></td>
                <td >
                        <?php echo $data['teacherinfo']; ?>
                    </td>
            </tr>     
        </tbody>
    </table>
    <table class="table table-striped table-bordered table-condensed list">
            <thead>
                <tr>
                    <td colspan="6"><b><strong>操作人信息</strong></b></td>
                </tr>
            </thead>
            
            <tbody>
                <tr>
                    <td ><strong>操作人用户名：</strong></td>
                    <td  ><?php echo $data['username']; ?></td>
                    <td ><strong>操作人权限：</strong></td>
                    <td colspan="3">
                            <?php echo $data['jurisdictioninfo']; ?>
                    </td>
                </tr>
                <tr>
                    <td width="15%"><strong>操作人姓名：</strong></td>
                    <td width="15%">
                            <?php echo $data['u_name']; ?>
                    </td>
                    <td width="15%"><strong>操作人所属单位：</strong></td>
                    <td width="15%">
                            <?php echo $data['userinfo']; ?></td>
                    <td width="15%"><strong>操作人所属单位名称：</strong></td>
                    <td width="25%">
                            <?php echo $data['collegeinfo_0']; ?></td>
                </tr>
            </tbody>
        </table>
        <table class="table table-striped table-bordered table-condensed list">
                <thead>
                    <tr>
                        <td colspan="6"><b><strong>操作信息</strong></b></td>
                    </tr>
                </thead>
                <tr>
                        <td ><strong>操作流水号：</strong></td>
                        <td colspan="5">
                                <?php echo $data['id']; ?>
                        </td>
                        
                    </tr>
                <tbody>
                    <tr>
                        <td width="15%"><strong>操作类型：</strong></td>
                        <td width="15%">
                                <?php echo $data['classinfo']; ?>
                        </td>
                        <td width="15%"><strong>操作分值：</strong></td>
                        <td width="15%">
                                <?php echo $data['score']; ?>
                        </td>
                        <td width="15%"><strong>操作状态：</strong></td>
                        <td width="25%"> <?php echo $data['operationinfo']; ?>
                               
                    </td>
                    </tr>
                    <tr>
                            <td width="15%"><strong>操作时间：</strong></td>
                            <td width="15%">
                                    <?php echo $data['datetime']; ?>
                            </td>
                            <td width="15%"><strong>操作IP：</strong></td>
                            <td width="15%" colspan="3">
                                    <?php echo $data['ip']; ?>
                            </td>
    
                        </tr>
                    <tr>
                        <td ><strong>学分操作一级分类：</strong></td>
                        <td colspan="5">
                                <?php echo $data['scoreinfo']; ?>
                        </td>
                        
                    </tr>
                    <tr>
                            
                            <td ><strong>学分操作二级分类：</strong></td>
                            <td colspan="5">
                                    <?php echo $data['scoresecinfo']; ?>
                                   
                            </td>
                        </tr>
                       
                </tbody>
            </table>
            
        </table>
        <form method="post" action="editpersonallogrun">
        <table class="table table-striped table-bordered table-condensed list">
                <thead>
                    <tr>
                        <td colspan="6"><b><strong>操作</strong></b></td>
                    </tr>
                </thead>
                <tr>
                        <td ><strong>当前状态：</strong></td>
                        <td colspan="5">
                                <?php echo $data['operationinfo']; ?>
                        </td>
                        
                    </tr>
                <tbody>
                    <tr>
                            <td width="15%"><strong>可选操作类型：</strong></td>
                            <td  width="15%">
                                    <select name="opstate">
                                            <option value="">未选择</option>
                                            <option value="4">申请撤销操作</option>
                                        </select>
                            </td>
                            <td width="15%"><strong>操作人：</strong></td>
                            <td  >
                                <input type="hidden" name="username" value="<?php echo $data['username']; ?>">
                                <input type="hidden" name="othername" value="<?php echo $data['u_name']; ?>">
                                
                                <input type="hidden" name="id" value="<?php echo $data['id']; ?>">
                                    <?php echo $data['u_name']; ?>
                                        </select>
                            </td>
                            
                        </tr>
                    <tr>
                        <td ><strong>备注：</strong></td>
                        <td colspan="5">
                                <textarea name="info" style="width: 98%" rows="4" cols="5" placeholder="支持中英文、数字、逗号、句号，且不能超过100个字符"></textarea>
                        </td>
                        
                    </tr>
                    <tr>
                            <td colspan="6">
            <!--                    <a href="help" class="btn btn-inverse">保存</a>-->
                                <input class="btn btn-inverse" id="find" type="submit" value="保存" />
                                <input class="btn btn-inverse" id="try" type="button" value="刷新" onclick="location.reload()"/>
            <!--                     <input class="btn btn-inverse" type="button" value="取消" /></td> -->
            &nbsp&nbsp&nbsp&nbsp信息保存成功如页面信息未更新请点击刷新按钮。
                        </tr>
                </tbody>
            </table>
        </from>
</body>
</html>
