<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:82:"/Applications/MAMP/htdocs/Tp5/public/../application/index/view/hddy1/editshow.html";i:1559557596;}*/ ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <title></title>
    <link rel="stylesheet" type="text/css" href="../../../public/css/bootstrap.min.css" />
    <link rel="stylesheet" type="text/css" href="../../../public/css/admin-all.css" />
    <link rel="stylesheet" type="text/css" href="../../../public/css/jquery-ui-1.8.22.custom.css" />
    <script type="text/javascript" src="../../../public/css/jquery-ui-1.8.22.custom.min.js"></script>
</head>
<body>
    <br>
    <table class="table table-striped table-bordered table-condensed list">
        <thead>
            <tr>
                <td colspan="6"><b>用户基本信息</b></td>
            </tr>
        </thead>
         
        <form method="post" action="editshowrun">
        <tbody>
            <tr>
                <td>用户编号</td>
                <td colspan="5"><?php echo $data['u_id']; ?><input name="u_id" value="<?php echo $data['u_id']; ?>" type="hidden"/></td>
            </tr>
            <tr>
                <td >用户名：</td>
                <td >
                    <input name="" value="<?php echo $data['username']; ?>" type="text" readonly/>
                </td>
                <td >姓名：</td>
                <td >
                    <input name="u_name" value="<?php echo $data['u_name']; ?>" type="text" /></td>
                <td >性别：</td>
                <td >
                      <select name="u_sex">
                        <option value="<?php echo $data['u_sex']; ?>">当前：<?php echo $data['u_sex']; ?></option>
                        <option value="男">男</option>
                        <option value="女">女</option>
                    </select>
                    
            </tr>
            <tr>
                <td >身份证号码：</td>
                <td >
                    <input name="user_id" value="<?php echo $data['user_id']; ?>" type="text" y/>
                </td>
                <td >所属单位：</td>
                <td >
                    <select name="u_class">
                        <option value="<?php echo $data['u_class']; ?>">当前：<?php echo $data['userinfo']; ?></option>
                        <option value="2">部门/单位</option>
                        <option value="1">二级学院</option>
                    </select></td>
                <td >所属单位名称：</td>
                <td >
                    <select name="u_classinfo">
                        <option value="<?php echo $data['u_classinfo']; ?>">当前：<?php echo $data['collegeinfo']; ?></option>
                        <?php if(is_array($data2) || $data2 instanceof \think\Collection || $data2 instanceof \think\Paginator): $i = 0; $__LIST__ = $data2;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$list): $mod = ($i % 2 );++$i;?>
                       <option value="<?php echo $list['collegeid']; ?>"><?php echo $list['collegeinfo']; ?></option>
                         <?php endforeach; endif; else: echo "" ;endif; ?>
                    </select>
                </td>
            </tr>
            <tr>
                <td >手机号码：</td>
                <td >
                    <input name="add" value="<?php echo $data['add']; ?>" type="text" />
                </td>
                <td >邮箱地址：</td>
                <td >
                    <input name="u_mail" value="<?php echo $data['u_mail']; ?>" type="text" /></td>
                <td >QQ号码：</td>
                <td >
                    <input name="qq" value="<?php echo $data['qq']; ?>" type="text" /></td>
            </tr>
            <tr>
                <td >微信号码：</td>
                <td >
                    <input name="vx" value="<?php echo $data['vx']; ?>" type="text" />
                </td>
                <td >账号状态：</td>
                <td colspan="3">
                <select name="state">
                        <option value="<?php echo $data['state']; ?>">当前：<?php echo $data['stateinfo']; ?></option>
                        <option value="1">启用</option>
                        <option value="2">停用</option>
                    </select>    
                </td>
            </tr>
        </tbody>
        
        <tfoot>
            <tr>
                <td colspan="6">
<!--                    <a href="help" class="btn btn-inverse">保存</a>-->
                    <input class="btn btn-inverse" id="find" type="submit" value="保存" />
                    <input class="btn btn-inverse" id="try" type="button" value="刷新" onclick="location.reload()"/>
<!--                     <input class="btn btn-inverse" type="button" value="取消" /></td> -->
&nbsp&nbsp&nbsp&nbsp信息保存成功如页面信息未更新请点击刷新按钮。
            </tr>
        </tfoot>
    </from>
      
    </table>
</body>
</html>
