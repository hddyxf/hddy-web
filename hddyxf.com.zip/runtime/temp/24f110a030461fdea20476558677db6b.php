<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:82:"/www/wwwroot/hddy.com/tp5/public/../application/index/view/apartment/showuser.html";i:1571885978;}*/ ?>
<!DOCTYPE html>
<html class="x-admin-sm">
    
    <head>
        <meta charset="UTF-8">
        <meta charset="UTF-8">
        <title>欢迎使用学生德育学分管理系统</title>
        <link rel="shortcut icon" href="../../logo.ico" />
        <link rel="stylesheet" href="/css/font.css">
         <link rel="stylesheet" href="/css/xadmin.css">
        <link rel="stylesheet" href="/css/theme.css">
        <script src="/lib/layui/layui.js" charset="utf-8"></script>
        <script type="text/javascript" src="/js/xadmin.js"></script>
        <!--[if lt IE 9]>
          <script src="https://cdn.staticfile.org/html5shiv/r29/html5.min.js"></script>
          <script src="https://cdn.staticfile.org/respond.js/1.4.2/respond.min.js"></script>
        <![endif]-->
    </head>
    
    <body>
        <div class="x-nav">
            <span class="layui-breadcrumb">
                <a>首页</a>
                <a>用户管理</a>
                <a>
                    <cite>查看用户</cite></a>
            </span>
            <a class="layui-btn layui-btn-small" style="line-height:1.6em;margin-top:3px;float:right;background-color:#4682B4" onclick="location.reload()" title="刷新">
                <i class="layui-icon layui-icon-refresh" style="line-height:30px"></i>
            </a>
        </div>
        <div class="layui-fluid">
            <div class="layui-row layui-col-space15">
                <div class="layui-col-md12">
                    <div class="layui-card">
                        <div class="layui-card-body ">
                            <form class="layui-form layui-col-space5">
                                <div class="layui-inline layui-show-xs-block">
                                    <input type="text"  placeholder="关键字查询" autocomplete="off" class="layui-input" name="ssk" id="ssk" ></div>
                                <div class="layui-inline layui-show-xs-block">
                                    <div class="layui-btn layui-btn-sm" lay-submit="" data-type="reload" id="tj" lay-filter="sreach" style="background-color:#4682B4">
                                        <i class="layui-icon">&#xe615;</i></div>
                                        <strong><i class="layui-icon">&nbsp&nbsp&#xe609;&nbsp支持用户名 用户姓名 所属单位名称的精确及模糊查询。(输入“_”可查询所有信息)</i> </strong>
                                
                                </div>
                            </form>
                        </div><table id="demo" lay-filter="test" class="layui-card-body" ></table>
                        <script type="text/html" id="barDemo" >
                            <a class="layui-btn layui-btn-normal" lay-event="detail" style="background-color:#708090">查看/编辑</a>
                            <a class="layui-btn layui-btn-normal" lay-event="resuserpwd" style="background-color:#FF5511">重置密码</a>
                            <a class="layui-btn layui-btn-danger layui-btn-xs" lay-event="del">删除用户</a>  
                        </script>
                    </div>
                </div>
            </div>
             <div >
                                本系统由 数据科学与人工智能学院 软件工程系 提供技术支持，并持有版权。
                        </div>
        </div>
         
    </body>
    <script type="text/html" id="sexTpl">
  {{#  if(d.stateinfo === '停用'){ }}
    <span style="color:#FF3333;">{{ d.stateinfo }}</span>
  {{#  } else { }}
    {{ d.stateinfo }}
  {{#  } }}
</script>
    <script>layui.use('laydate',
        function() {
            var laydate = layui.laydate;

            //执行一个laydate实例
            laydate.render({
                elem: '#start' //指定元素
            });

            //执行一个laydate实例
            laydate.render({
                elem: '#end' //指定元素
            });
            

        });</script>
    
<script>
  layui.use('table', function(){
  var table = layui.table;
  var index = layer.load(2);
  
  table.render({
    elem: '#demo'
    ,url:'userlist'
    ,toolbar: '#toolbarDemo'
    ,title: '用户数据表'
    ,cols: [[
    {type:'numbers',title:'序号',},
       {field:'username', title:'用户名',width:100}
      ,{field:'u_name', title:'姓名',width:80}
      ,{field:'u_sex', title:'性别',width:55}
      
      ,{field:'userinfo', title:'所属单位',width:120}
      ,{field:'collegeinfo', title:'所属单位名称',width:200}
      ,{field:'add', title:'联系方式',width:120}
      ,{field:'jurisdictioninfo', title:'权限',width:100}
       ,{field:'stateinfo', title:'状态',templet: '#sexTpl',width:80}
      ,{ field:'1',title:'操作', toolbar: '#barDemo',}]]
    ,page: true
    ,done:function () {
                        layer.close(index) //加载完数据
                    }
  });
       

        var active = {
            reload: function(){
                var index = layer.load(2);
                var username = $('#ssk').val(); //传入搜索值 
                //console.log((username));验证值是否获取
                //执行重载
                table.reload('demo', {
                    url : 'usercheck',
                    method:'post',
                    page: {
                        curr: 1 //重新从第 1 页开始
                    }
                    ,where: { //类似于 data
                        username:username //传入日期参数
                        ,done:function () {
                        layer.close(index) //加载完数据
                    }
                    }
                });
            }
        };
        
      var table = layui.table;
      
      //监听单元格编辑
     table.on('tool(test)', function(obj){
    var data = obj.data;
   
    if(obj.event === 'detail'){
         layer.open({
    type: 2,
    title: '查看用户详情',
    shadeClose: true,
    shade: 0.4,
    area: ['90%', '90%'],
    
    content: 'editshow?id='+data.u_id //iframe的url
  });
    }
    
    if(obj.event === 'resuserpwd'){
        layer.confirm('确定将用户:  ' + data.username + '  的密码恢复为123456吗？', function (index) {
                    
                    $.ajax({
                        url: "resuserpwdrun",
                        type: "POST",
                        data: {'username': data.username,},
                        async: false,
                        success: function (data) {
                            var res = JSON.parse(data)
                            var status = parseInt(res.status);
                            if (status == 1) {
                                layer.msg('操作失败！', {icon: 0})
                            }  else {
                                layer.msg('操作成功！', {icon: 1})
                            }
                        }
                    })
                    layer.close(index);
                    PowerTable.reload(); //重新加载表格
                });
    }
    if (obj.event === 'del') {
                layer.confirm('确定删除用户:  ' + data.username + '  吗？', function (index) {
                    obj.del();  //页面表格内部删除
                    $.ajax({
                        url: "deluser",
                        type: "POST",
                        data: {'u_id': data.u_id,},
                        async: false,
                        success: function (data) {
                            var res = JSON.parse(data)
                            var status = parseInt(res.status);
                            if (status == 1) {
                                layer.msg('删除失败！', {icon: 0})
                            }  else {
                                layer.msg('删除成功！', {icon: 1})
                            }
                        }
                    })
                    layer.close(index);
                    PowerTable.reload(); //重新加载表格
                });
    }
    else{
    console.log(('111'));
    }
  });
    
        $('#tj').on('click', function(){
            var type = $(this).data('type');
            //不能为空验证
            if( $('#ssk').val()==""){
                layer.msg('查询内容不能为空');
                return false;
            }
            active[type] ? active[type].call(this) : '';
        });
     $(document).on('keydown',function(e){
      if(e.keyCode == 13){
        $('#tj').trigger('click');
        return false;
      }
        })
         });
         
</script>
 
</html>