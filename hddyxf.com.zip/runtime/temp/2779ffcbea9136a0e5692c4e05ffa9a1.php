<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:85:"/www/wwwroot/www.hddy.com/tp5/public/../application/index/view/instructor/addstu.html";i:1560826318;}*/ ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <title></title>
    <link rel="stylesheet" type="text/css" href="/css/bootstrap.min.css" />
    <link rel="stylesheet" type="text/css" href="/css/admin-all.css" />
    <link rel="stylesheet" type="text/css" href="/css/jquery-ui-1.8.22.custom.css" />
    <script type="text/javascript" src="/css/jquery-ui-1.8.22.custom.min.js"></script>
    <script>
            function showCustomer(str)
            {
              var xmlhttp;    
              if (str=="")
              {
                document.getElementById("txtHint").innerHTML="";
                return;
              }
              if (window.XMLHttpRequest)
              {
                // IE7+, Firefox, Chrome, Opera, Safari 浏览器执行代码
                xmlhttp=new XMLHttpRequest();
              }
              else
              {
                // IE6, IE5 浏览器执行代码
                xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
              }
              xmlhttp.onreadystatechange=function()
              {
                if (xmlhttp.readyState==4 && xmlhttp.status==200)
                {
                  document.getElementById("txtHint").innerHTML=xmlhttp.responseText;
                }
              }
              xmlhttp.open("GET","classmore?q="+str,true);
              xmlhttp.send();
            }
            </script>
</head>
<body>
    <div class="alert alert-info">当前位置<b class="tip"></b>学生管理<b class="tip"></b>添加学生</div>
    <table class="table table-striped table-bordered table-condensed list">
        <thead>
            <tr>
                <td colspan="6"><b>学生基本信息</b></td>
            </tr>
        </thead>
        <form method="post" action="addsturun">
        <tbody>
           
            <tr>
                <td >学号：<font color="FF0000">*</font></td>
                <td >
                    <input name="s_id" value="" type="text" placeholder="10-15位全数字"/>
                </td>
                <td >姓名：<font color="FF0000">*</font></td>
                <td >
                    <input name="s_name" value="" type="text" placeholder="5位以内全汉字"/></td>
                <td >性别：</td>
                <td >
                    <input name="s_sex" type="radio" value="男" checked="checked"/>  男
                    <input name="s_sex" type="radio" value="女"  />  女
                </td>
            </tr>
            <tr>
                <td >身份证号码：<font color="FF0000">*</font></td>
                <td >
                    <input name="s_proid" value="" type="text" placeholder="18位全数字，最后一位可以为X"/>
                </td>
                <td >学生手机号码：</td>
                <td ><input name="s_add" value="" type="text" placeholder="11位全数字"/>
                    </td>
                <td >家庭住址：</td>
                <td >
                   <input name="s_home" value="" type="text" placeholder="20个字符以内"/>
                    </td>
            </tr>
            <tr>
                    <td >行政班：<font color="FF0000">*</font></td>
                    <td >
                            <select name="s_class" onchange="showCustomer(this.value)">
                                    <option value="">未选择</option>
                                     <?php if(is_array($data) || $data instanceof \think\Collection || $data instanceof \think\Paginator): $i = 0; $__LIST__ = $data;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$list): $mod = ($i % 2 );++$i;?>
                                    <option value="<?php echo $list['class']; ?>"><?php echo $list['class']; ?></option>
                                     <?php endforeach; endif; else: echo "" ;endif; ?>
                                </select>
                    </td>
                    <td >寝室号及床位：<font color="FF0000">*</font></td>
                    <td colspan="3">
                    <input name="s_room" value="" type="text" placeholder="5110-1，即5公寓1楼10号寝室1床"/>
                    </td>
                </tr>
             <tr id="txtHint">
                    <td colspan="6">选择行政班后相关信息将显示</td>
            <tr>
                <td >父亲姓名：</td>
                <td >
                    <input name="s_dadname" value="" type="text" placeholder="5位以内全汉字"/>
                </td>
                <td >父亲手机号码：</td>
                <td colspan="3">
                    <input name="s_dadadd" value="" type="text" placeholder="11位全数字"/></td>
            </tr>
            <tr>
                <td >母亲姓名：</td>
                <td >
                    <input name="s_mumname" value="" type="text"  placeholder="5位以内全汉字"/>
                </td>
                <td >母亲手机号码：</td>
                <td colspan="3">
                    <input name="s_mumadd" value="" type="text" placeholder="11位全数字"/></td>
            </tr>
            
        </tbody>
        <tfoot>
            <tr>
                <td colspan="6">
<!--                    <a href="help" class="btn btn-inverse">保存</a>-->
                    <input class="btn btn-inverse" type="submit" value="提交" />
                    <input class="btn btn-inverse" type="reset" value="清空" />
<!--                     <input class="btn btn-inverse" type="button" value="取消" /></td> -->
    

            </tr>
        </tfoot>
    </from>
    </table>
</body>
</html>
