<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:80:"/Applications/MAMP/htdocs/tp5/public/../application/index/view/hddy1/addstu.html";i:1558974247;}*/ ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <title></title>
    <link rel="stylesheet" type="text/css" href="../../../public/css/bootstrap.min.css" />
    <link rel="stylesheet" type="text/css" href="../../../public/css/admin-all.css" />
    <link rel="stylesheet" type="text/css" href="../../../public/css/jquery-ui-1.8.22.custom.css" />
    <script type="text/javascript" src="../../../public/css/jquery-ui-1.8.22.custom.min.js"></script>
    

      
</head>
<body>
    <div class="alert alert-info">当前位置<b class="tip"></b>学生管理<b class="tip"></b>添加学生</div>
    <table class="table table-striped table-bordered table-condensed list">
        <thead>
            <tr>
                <td colspan="6"><b>学生基本信息</b></td>
            </tr>
        </thead>
        <form method="post" action="addsturun">
        <tbody>
           
            <tr>
                <td >学号：</td>
                <td >
                    <input name="s_id" value="" type="text" />
                </td>
                <td >姓名：</td>
                <td >
                    <input name="s_name" value="" type="text" /></td>
                <td >性别：</td>
                <td >
                    <input name="s_sex" type="radio" value="男" checked="checked"/>  男
                    <input name="s_sex" type="radio" value="女"  />  女
                </td>
            </tr>
            <tr>
                <td >身份证号码：</td>
                <td >
                    <input name="s_nation" value="" type="text" />
                </td>
                <td >联系方式：</td>
                <td ><input name="s_add" value="" type="text" />
                    </td>
                <td >家庭住址：</td>
                <td >
                   <input name="s_home" value="" type="text" />
                    </td>
            </tr>
             <tr>
                <td >所在学院：</td>
                <td >
                    <select name="collegeid">
                        <option >未选择</option>
                         <?php if(is_array($data) || $data instanceof \think\Collection || $data instanceof \think\Paginator): $i = 0; $__LIST__ = $data;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$list): $mod = ($i % 2 );++$i;?>
                        <option value="<?php echo $list['collegeid']; ?>"><?php echo $list['collegeinfo']; ?></option>
                         <?php endforeach; endif; else: echo "" ;endif; ?>
                    </select>
                </td>
                <td >专业：</td>
                <td ><select name="majorid">
                        <option >未选择</option>
                       <?php if(is_array($data1) || $data1 instanceof \think\Collection || $data1 instanceof \think\Paginator): $i = 0; $__LIST__ = $data1;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$list): $mod = ($i % 2 );++$i;?>
                        <option value="<?php echo $list['majorid']; ?>"><?php echo $list['majorinfo']; ?></option>
                         <?php endforeach; endif; else: echo "" ;endif; ?>
                    </select>
                    </td>
                <td >辅导员：</td>
                <td >
                    <select name="teacherid">
                        <option >未选择</option>
                        <?php if(is_array($data2) || $data2 instanceof \think\Collection || $data2 instanceof \think\Paginator): $i = 0; $__LIST__ = $data2;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$list): $mod = ($i % 2 );++$i;?>
                        <option value="<?php echo $list['teacherid']; ?>"><?php echo $list['teacherinfo']; ?></option>
                         <?php endforeach; endif; else: echo "" ;endif; ?>
                    </select>
                    </td>
            </tr>
            <tr>
                <td >行政班：</td>
                <td >
                    <input name="s_class" value="" type="text" />
                </td>
                <td >寝室号及床位：</td>
                <td colspan="3">
                <input name="s_room" value="" type="text" />例：5110-1，即5公寓1楼10号寝室1号床位。
                </td>
            </tr>
            <tr>
                <td >父亲姓名：</td>
                <td >
                    <input name="s_dadname" value="" type="text" />
                </td>
                <td >父亲联系方式：</td>
                <td colspan="3">
                    <input name="s_dadadd" value="" type="text" /></td>
            </tr>
            <tr>
                <td >母亲姓名：</td>
                <td >
                    <input name="s_mumname" value="" type="text" />
                </td>
                <td >母亲联系方式：</td>
                <td colspan="3">
                    <input name="s_mumadd" value="" type="text" /></td>
            </tr>
            
        </tbody>
        <tfoot>
            <tr>
                <td colspan="6">
<!--                    <a href="help" class="btn btn-inverse">保存</a>-->
                    <input class="btn btn-inverse" type="submit" value="提交" />
                    <input class="btn btn-inverse" type="reset" value="清空" />
<!--                     <input class="btn btn-inverse" type="button" value="取消" /></td> -->
    

            </tr>
        </tfoot>
    </from>
    </table>
</body>
</html>
